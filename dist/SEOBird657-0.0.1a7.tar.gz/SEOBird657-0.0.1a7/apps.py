from django.apps import AppConfig


class Seobird657Config(AppConfig):
    name = 'seobird657'
